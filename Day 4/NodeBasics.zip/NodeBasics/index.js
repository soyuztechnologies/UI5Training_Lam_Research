var reuse = require('./reuse');

console.log("Welcome to Node JS");


console.log(reuse.addNumber(10,20));
console.log(reuse.addNewNumber(10,20));
console.log(reuse.calcSize([1,2,3,4,7]));
reuse.printJSONComp({empId: 10, empName: "anubhav", smoker : false});
reuse.printJSONValues({empId: 10, empName: "anubhav", smoker : false});
