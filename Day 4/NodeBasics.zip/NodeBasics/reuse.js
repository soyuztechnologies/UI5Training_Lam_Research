module.exports = {
    tax : 500,
    addNumber: function(a,b){
        return a + b + this.tax;
    },
    addNewNumber: (a,b) => {
        return a + b + this.tax;
    },
    calcSize: (arr) => {
        return arr.length;
    },
    printJSONComp : (json) => {
        for(item in json){
            console.log(item);
        }
    },
    printJSONValues: (json) => {
            for(item in json){
                console.log(json[item]);
            }
        }
}