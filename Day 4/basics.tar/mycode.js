
            function onAsync(){
                
                var oLabel = document.getElementById("idtest");
                oLabel.innerHTML = "function started";

                setTimeout(function(){
                    debugger;
                    oLabel.innerHTML = oLabel.innerHTML + "<div />" + "function Ended";
                },5000);

                
            }

            function onLogin(){
                //Step 1: get the object of my fields
                var oUser = document.getElementById("iduser");
                //var oPwd = ;
                //Step 2: get the value from those field objects
                var sUserName = oUser.value;
                //this is called Chaining concept
                var sPassword = document.getElementById("idpwd").value;
                //Step 3: compare if both are same
                if(sUserName === sPassword){
                    //Step 4: login done
                    document.write("Login success ");
                }else{
                     //step 5: show error
                    var oLabel = document.getElementById("idMsg");
                    oLabel.innerHTML = "Login failed";
                }
                
               
            }

            //internal JS
            function callMe(){
                //code inside here
                //output function 1
                //alert('welcome to js');
                //output function 2
                console.log("hey amigo!");
                //output function 3
                document.write("<h3 style='color:blue'>How are you!</h3>");
            }
            var check = false;
            function onMagic(){

                //Step 1: get all the content areas of box - superman
                var aBoxElements = document.getElementsByClassName("superman");
                //Step 2: Loop over each element
                for(var i=0;i<aBoxElements.length;i++){
                    //Step 3: Take each element and change its style
                    var oElement = aBoxElements[i];
                    if(check === false){
                        oElement.style.backgroundColor = "black";
                        oElement.style.color = "red";
                        if(i === aBoxElements.length - 1){
                            check = true;
                        }                        
                    }else{ 
                        oElement.style.backgroundColor = "yellow";
                        oElement.style.color = "black";
                        if(i === aBoxElements.length - 1){
                            check = false;
                        }
                    }
                    
                }
 
            }

            function onHide(){
                //$(".avengers").hide();
                $(".avengers").fadeOut(5000, function(){
                    alert("effect is done");
                });
                
            }

            function onShow(){
                //$(".avengers").show();
                $(".avengers").fadeIn(5000);
            }

            function onDance(){
                $("#iduser").animate({
                    width: "10px",
                    height: "10px"
                }, function(){
                    $(this).animate({
                        width: "280px",
                        height: "30px"
                    }, function(){
                        onDance();
                    })
                },);
            }

            function callExternalAPI(){
                $.ajax("https://api.covidtracking.com/v1/us/daily.json",{
                    success: function(data, status){
                        console.log(data);
                    }
                });
            }