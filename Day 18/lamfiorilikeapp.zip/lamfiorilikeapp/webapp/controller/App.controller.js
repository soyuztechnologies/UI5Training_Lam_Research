sap.ui.define([
    'lam/fin/ar/controller/BaseController'
], function(BaseController) {
    'use strict';
    return BaseController.extend("lam.fin.ar.controller.App",{
        onInit: function(){
            
        }
    });
});