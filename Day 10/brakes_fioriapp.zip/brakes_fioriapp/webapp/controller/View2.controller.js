sap.ui.define([
    'tcs/fin/payroll/controller/BaseController',
    'sap/m/MessageBox',
    'sap/m/MessageToast'
], function(BaseController, MessageBox, MessageToast) {
    'use strict';
    return BaseController.extend("tcs.fin.payroll.controller.View2",{
        onInit: function(){
            
        },
        onBack: function(){
            this.getView().getParent().to("idView1");
        },
        onSave: function(){
            MessageBox.confirm("Do you like to save",{
                onClose: function(status){
                    if(status === "OK"){
                        MessageToast.show("The order is created successfully");
                    }else{
                        MessageBox.error("An issue occurred");
                    }
                }
            });
        },
        onCancel: function(){

        }
    });
});