sap.ui.define([
    'lam/fin/ar/controller/BaseController',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/m/MessageToast'
], function(BaseController, Filter,FilterOperator, JSONModel, MessageBox, MessageToast) {
    'use strict';
    return BaseController.extend("lam.fin.ar.controller.Add",{
        onInit: function(){
            var oModel = new JSONModel();
            oModel.setData({
                prodData: {
                                "ProductId": "",
                                "TypeCode": "PR",
                                "Category": "Notebooks",
                                "Name": "",
                                "Description": "",
                                "SupplierId": "100000051",
                                "SupplierName": "TECUM",
                                "TaxTarifCode": 1,
                                "MeasureUnit": "EA",
                                "Price": "0.0000",
                                "CurrencyCode": "USD",
                                "DimUnit": "CM"
                        }
            });
            this.getView().setModel(oModel,'prod');
        },
        onSave: function(){
            //Step 1: Get The OData Model object - default
            var oDataModel = this.getView().getModel();
            //Step 2: Prepare payload and pre-check
            var oModel = this.getView().getModel('prod');
            var payload = oModel.getProperty("/prodData");
            if(!payload.ProductId){
                MessageBox.error("Please enter valid product id");
                return "";
            }
            //Step 3: Fire POST request to SAP
            oDataModel.create("/ProductSet", payload ,{
                //Step 4: We get the response back
                success: function(){
                    MessageToast.show("The Product has been created in SAP Now");
                },
                error: function(oErr){
                    MessageBox.error("Something gone wrong, please try again!");
                }
            });
            

        }
    });
});