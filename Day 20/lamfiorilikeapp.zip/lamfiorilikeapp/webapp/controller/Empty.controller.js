sap.ui.define([
    'lam/fin/ar/controller/BaseController',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator'
], function(BaseController, Filter,FilterOperator) {
    'use strict';
    return BaseController.extend("lam.fin.ar.controller.Empty",{
        onInit: function(){
            
        }
    });
});